#pragma once
// ============================================================
// LiteBox — registry.h
// Thread-safe container registry (Lab 09: mutex locks)
// ============================================================

#include "container.h"
#include "utils.h"
#include <map>
#include <pthread.h>
#include <semaphore.h>
#include <fstream>
#include <sstream>
#include <iostream>

// Path where registry state is persisted (Lab 10: file I/O)
#define REGISTRY_FILE "/var/lib/litebox/registry.csv"
#define LITEBOX_RUN_DIR "/var/lib/litebox/containers/"

class Registry {
public:
    // -------------------------------------------------------
    // Constructor — init mutex & semaphore (Lab 09)
    // -------------------------------------------------------
    Registry() {
        pthread_mutex_init(&mutex_, nullptr);
        // Semaphore: allow at most MAX_CONTAINERS concurrent containers
        sem_init(&spawn_sem_, 0, MAX_CONTAINERS);
        mkdir_p("/var/lib/litebox/containers");
        load_from_disk();
    }

    ~Registry() {
        pthread_mutex_destroy(&mutex_);
        sem_destroy(&spawn_sem_);
    }

    // -------------------------------------------------------
    // add() — register a new container (acquires semaphore)
    // -------------------------------------------------------
    bool add(const ContainerInfo& info) {
        // sem_wait limits concurrent spawns (Lab 09: semaphores)
        if (sem_trywait(&spawn_sem_) != 0) {
            std::cerr << "[litebox] Max containers reached (" << MAX_CONTAINERS << ")\n";
            return false;
        }
        pthread_mutex_lock(&mutex_);
        containers_[info.config.id] = info;
        persist(info);
        pthread_mutex_unlock(&mutex_);
        return true;
    }

    // -------------------------------------------------------
    // remove() — unregister a container (releases semaphore)
    // -------------------------------------------------------
    void remove(const std::string& id) {
        pthread_mutex_lock(&mutex_);
        auto it = containers_.find(id);
        if (it != containers_.end()) {
            containers_.erase(it);
            remove_persisted(id);
            sem_post(&spawn_sem_); // free one slot
        }
        pthread_mutex_unlock(&mutex_);
    }

    // -------------------------------------------------------
    // get() — find container by ID (thread-safe read)
    // -------------------------------------------------------
    bool get(const std::string& id, ContainerInfo& out) {
        pthread_mutex_lock(&mutex_);
        auto it = containers_.find(id);
        bool found = (it != containers_.end());
        if (found) out = it->second;
        pthread_mutex_unlock(&mutex_);
        return found;
    }

    // -------------------------------------------------------
    // update_state() — update a container's state
    // -------------------------------------------------------
    void update_state(const std::string& id, ContainerState state) {
        pthread_mutex_lock(&mutex_);
        if (containers_.count(id)) containers_[id].state = state;
        pthread_mutex_unlock(&mutex_);
    }

    // -------------------------------------------------------
    // all() — return snapshot of all containers
    // -------------------------------------------------------
    std::map<std::string, ContainerInfo> all() {
        pthread_mutex_lock(&mutex_);
        auto copy = containers_;
        pthread_mutex_unlock(&mutex_);
        return copy;
    }

    // -------------------------------------------------------
    // count() — number of active containers
    // -------------------------------------------------------
    int count() {
        pthread_mutex_lock(&mutex_);
        int n = (int)containers_.size();
        pthread_mutex_unlock(&mutex_);
        return n;
    }

private:
    std::map<std::string, ContainerInfo> containers_;
    pthread_mutex_t mutex_;   // Lab 09: mutex guard
    sem_t           spawn_sem_; // Lab 09: semaphore

    // -------------------------------------------------------
    // persist() — write one container entry to CSV
    //             (Lab 10: C++ file handling)
    // -------------------------------------------------------
    void persist(const ContainerInfo& info) {
        std::ofstream f(REGISTRY_FILE, std::ios::app);
        if (!f.is_open()) return;
        int state = (int)info.state;
        f << info.config.id << ","
          << info.pid        << ","
          << info.config.image << ","
          << info.config.hostname << ","
          << state           << ","
          << info.start_time << ","
          << info.rootfs     << "\n";
    }

    void remove_persisted(const std::string& id) {
        // Rewrite file without this ID
        std::ifstream in(REGISTRY_FILE);
        std::string   tmp = std::string(REGISTRY_FILE) + ".tmp";
        std::ofstream out(tmp);
        std::string   line;
        while (std::getline(in, line)) {
            if (line.substr(0, id.size()) != id) out << line << "\n";
        }
        in.close(); out.close();
        rename(tmp.c_str(), REGISTRY_FILE);
    }

    void load_from_disk() {
        // On startup re-read persisted entries (surviving restarts)
        std::ifstream f(REGISTRY_FILE);
        std::string line;
        while (std::getline(f, line)) {
            if (line.empty()) continue;
            std::istringstream ss(line);
            std::string tok;
            ContainerInfo info;
            std::getline(ss, info.config.id,       ',');
            std::string pid_s; std::getline(ss, pid_s, ',');
            std::getline(ss, info.config.image,    ',');
            std::getline(ss, info.config.hostname,  ',');
            std::string st_s;  std::getline(ss, st_s,  ',');
            std::getline(ss, info.start_time,       ',');
            std::getline(ss, info.rootfs,            ',');
            info.pid   = (pid_t)std::stoi(pid_s.empty() ? "0" : pid_s);
            info.state = ContainerState::STOPPED; // assume stopped on reload
            containers_[info.config.id] = info;
        }
    }
};
