#pragma once
// ============================================================
// LiteBox — monitor.h
// Real-time resource monitor dashboard
// Lab 08: pthreads | Lab 09: mutex | Reads /proc/<pid>/
// ============================================================

#include "container.h"
#include "registry.h"
#include "utils.h"
#include <pthread.h>
#include <iostream>
#include <sstream>
#include <fstream>
#include <unistd.h>
#include <cstring>

// -----------------------------------------------------------
// read_proc_stat() — read CPU jiffies from /proc/<pid>/stat
// -----------------------------------------------------------
static bool read_proc_stat(pid_t pid, unsigned long long& utime,
                            unsigned long long& stime, int& num_threads)
{
    std::string path = "/proc/" + std::to_string(pid) + "/stat";
    std::ifstream f(path);
    if (!f.is_open()) return false;
    std::string line;
    std::getline(f, line);

    // Fields: pid comm state ppid pgroup session tty_nr tpgid flags
    //         minflt cminflt majflt cmajflt utime stime ... num_threads
    std::istringstream ss(line);
    std::string tok;
    int field = 0;
    utime = stime = 0; num_threads = 0;
    while (ss >> tok) {
        field++;
        if (field == 14) utime       = std::stoull(tok);
        if (field == 15) stime       = std::stoull(tok);
        if (field == 20) num_threads = std::stoi(tok);
    }
    return true;
}

// -----------------------------------------------------------
// read_proc_status() — read RSS from /proc/<pid>/status
// -----------------------------------------------------------
static long read_rss_kb(pid_t pid) {
    std::string path = "/proc/" + std::to_string(pid) + "/status";
    std::ifstream f(path);
    if (!f.is_open()) return 0;
    std::string line;
    while (std::getline(f, line)) {
        if (line.rfind("VmRSS:", 0) == 0) {
            std::istringstream ss(line);
            std::string label; long kb;
            ss >> label >> kb;
            return kb;
        }
    }
    return 0;
}

// -----------------------------------------------------------
// compute_cpu_percent() — compare two stat snapshots
// -----------------------------------------------------------
static double compute_cpu(unsigned long long u1, unsigned long long s1,
                           unsigned long long u2, unsigned long long s2,
                           unsigned long long elapsed_jiffies)
{
    if (elapsed_jiffies == 0) return 0.0;
    unsigned long long proc_jiffies = (u2 + s2) - (u1 + s1);
    return (100.0 * proc_jiffies) / elapsed_jiffies;
}

// -----------------------------------------------------------
// MonitorThread — background pthread (Lab 08)
// -----------------------------------------------------------
class MonitorThread {
public:
    explicit MonitorThread(Registry* reg) : reg_(reg), running_(false) {}

    void start() {
        running_ = true;
        pthread_create(&thread_, nullptr, MonitorThread::thread_fn, this);
        std::cout << "[monitor] Dashboard thread started (PID poll every 1s)\n";
    }

    void stop() {
        running_ = false;
        pthread_join(thread_, nullptr);
    }

    // -------------------------------------------------------
    // print_dashboard() — render live stats table to stdout
    // -------------------------------------------------------
    void print_dashboard() {
        auto containers = reg_->all();
        if (containers.empty()) {
            std::cout << Color::YELLOW << "[litebox] No containers running.\n"
                      << Color::RESET;
            return;
        }

        // Clear screen & print header
        std::cout << "\033[2J\033[H"; // ANSI: clear + cursor home
        std::cout << Color::BOLD << Color::CYAN
                  << "╔══════════════════════════════════════════════════════════╗\n"
                  << "║          LiteBox — Real-Time Container Dashboard         ║\n"
                  << "╚══════════════════════════════════════════════════════════╝\n"
                  << Color::RESET;

        printf("%-12s %-8s %-10s %-12s %-8s %-10s\n",
               "CONTAINER", "PID", "STATUS", "MEM(KB)", "THREADS", "CPU%");
        std::cout << std::string(64, '-') << "\n";

        for (auto& [id, info] : containers) {
            if (info.state != ContainerState::RUNNING) continue;

            long rss      = read_rss_kb(info.pid);
            int  threads  = 0;
            unsigned long long u1=0, s1=0, u2=0, s2=0;
            read_proc_stat(info.pid, u1, s1, threads);
            usleep(200000); // 200ms sample window
            read_proc_stat(info.pid, u2, s2, threads);

            long hz = sysconf(_SC_CLK_TCK);
            double cpu = compute_cpu(u1, s1, u2, s2, hz / 5); // /5 because 200ms

            // Colour-code by CPU usage
            const char* cpu_colour = Color::GREEN;
            if (cpu > 70.0) cpu_colour = Color::RED;
            else if (cpu > 40.0) cpu_colour = Color::YELLOW;

            printf("%-12s %-8d %-10s %-12ld %-8d ",
                   id.substr(0,8).c_str(),
                   info.pid,
                   "RUNNING",
                   rss,
                   threads);
            printf("%s%.1f%%%s\n", cpu_colour, cpu, Color::RESET);
        }
        std::cout << Color::BOLD << "\n[" << now_iso() << "] "
                  << reg_->count() << " container(s) active"
                  << Color::RESET << "\n";
    }

private:
    Registry*  reg_;
    pthread_t  thread_;
    bool       running_;

    // -------------------------------------------------------
    // thread_fn() — static entry point for pthread_create
    //               Polls every MONITOR_INTERVAL_MS (1 second)
    // -------------------------------------------------------
    static void* thread_fn(void* arg) {
        auto* self = static_cast<MonitorThread*>(arg);
        while (self->running_) {
            self->print_dashboard();
            usleep(MONITOR_INTERVAL_MS * 1000);
        }
        return nullptr;
    }
};
