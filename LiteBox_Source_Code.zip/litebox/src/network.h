#pragma once
// ============================================================
// LiteBox — network.h
// Container networking: veth pairs + network namespaces
// Uses iproute2 (ip link / ip addr / ip netns) commands
// ============================================================

#include "utils.h"
#include <string>
#include <iostream>
#include <sstream>

class NetworkManager {
public:
    // -------------------------------------------------------
    // setup_veth() — create veth pair & assign to container netns
    //   Returns the assigned IP address (10.200.x.x)
    // -------------------------------------------------------
    static std::string setup_veth(const std::string& id,
                                   pid_t              container_pid,
                                   std::string&       veth_host_out,
                                   std::string&       veth_cont_out)
    {
        // Derive short 4-char suffix from container ID
        std::string suffix = id.substr(0, 4);
        veth_host_out = "lb-h-" + suffix;   // host side
        veth_cont_out = "lb-c-" + suffix;   // container side

        // Compute a unique IP in 10.200.x.x range using ID bytes
        int octet3 = std::stoi(id.substr(0, 2), nullptr, 16) % 256;
        int octet4 = std::stoi(id.substr(2, 2), nullptr, 16) % 254 + 1;
        std::string cont_ip   = "10.200." + std::to_string(octet3)
                              + "." + std::to_string(octet4) + "/24";
        std::string gw_ip     = "10.200." + std::to_string(octet3) + ".1";

        std::string vhst = veth_host_out;
        std::string vcnt = veth_cont_out;

        // 1. Create veth pair
        run_cmd("ip link add " + vhst + " type veth peer name " + vcnt +
                " 2>/dev/null || true");

        // 2. Move container side into the container's network namespace
        run_cmd("ip link set " + vcnt + " netns " +
                std::to_string(container_pid) + " 2>/dev/null || true");

        // 3. Bring host side up and assign gateway IP
        run_cmd("ip addr add " + gw_ip + "/24 dev " + vhst +
                " 2>/dev/null || true");
        run_cmd("ip link set " + vhst + " up 2>/dev/null || true");

        // 4. Inside container namespace: assign IP, bring up lo + veth
        std::string ns_exec = "nsenter -t " + std::to_string(container_pid)
                             + " -n -- ";
        run_cmd(ns_exec + "ip addr add " + cont_ip + " dev " + vcnt +
                " 2>/dev/null || true");
        run_cmd(ns_exec + "ip link set " + vcnt + " up 2>/dev/null || true");
        run_cmd(ns_exec + "ip link set lo up 2>/dev/null || true");
        run_cmd(ns_exec + "ip route add default via " + gw_ip +
                " 2>/dev/null || true");

        // 5. Enable NAT on host for container outbound traffic
        run_cmd("iptables -t nat -A POSTROUTING -s 10.200.0.0/16 "
                "-j MASQUERADE 2>/dev/null || true");
        run_cmd("echo 1 > /proc/sys/net/ipv4/ip_forward 2>/dev/null || true");

        std::cout << "[net] Container " << id << " assigned IP "
                  << cont_ip << " via " << vhst << "\n";

        return cont_ip;
    }

    // -------------------------------------------------------
    // teardown_veth() — delete veth pair on container stop
    // -------------------------------------------------------
    static void teardown_veth(const std::string& veth_host) {
        run_cmd("ip link del " + veth_host + " 2>/dev/null || true");
        std::cout << "[net] Removed veth " << veth_host << "\n";
    }
};
