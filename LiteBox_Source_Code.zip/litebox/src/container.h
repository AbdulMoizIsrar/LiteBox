#pragma once
// ============================================================
// LiteBox — Lightweight Linux Container Runtime
// container.h  |  Core data structures & declarations
// Student: Abdul Moiz Israr | SP24-BCS-002 | BCS-5A
// CSC322 — Operating Systems | COMSATS University Islamabad
// ============================================================

#include <string>
#include <vector>
#include <map>

// -----------------------------------------------------------
// Container state enumeration
// -----------------------------------------------------------
enum class ContainerState {
    RUNNING,
    STOPPED,
    PAUSED
};

// -----------------------------------------------------------
// ContainerConfig — everything needed to spawn a container
// -----------------------------------------------------------
struct ContainerConfig {
    std::string id;           // Unique 8-char hex ID
    std::string image;        // Filesystem image/directory path
    std::string hostname;     // UTS hostname for the container
    std::string command;      // Command to run inside container
    long        mem_limit_mb; // Memory cap in MiB (cgroups v2)
    int         cpu_quota;    // CPU quota % (0 = unlimited)
    bool        network;      // Enable veth networking
};

// -----------------------------------------------------------
// ContainerInfo — live runtime info stored in registry
// -----------------------------------------------------------
struct ContainerInfo {
    ContainerConfig config;
    pid_t           pid;        // Host-side PID of container root
    ContainerState  state;
    std::string     veth_host;  // Host-side veth interface name
    std::string     veth_cont;  // Container-side veth name
    std::string     ip_addr;    // Assigned virtual IP
    std::string     start_time; // ISO timestamp
    std::string     rootfs;     // Path to container rootfs
    std::string     cgroup_path;// Path under /sys/fs/cgroup/
};

// -----------------------------------------------------------
// ResourceStats — snapshot read from /proc/<pid>/
// -----------------------------------------------------------
struct ResourceStats {
    std::string container_id;
    pid_t       pid;
    double      cpu_percent;
    long        mem_rss_kb;
    int         num_threads;
    std::string state;
};

// -----------------------------------------------------------
// IPC message structure (POSIX message queues)
// -----------------------------------------------------------
struct IpcMessage {
    long   mtype;          // message type (container numeric ID)
    char   sender[16];     // sender container ID
    char   payload[224];   // actual message payload
};

// Constants
constexpr int    LITEBOX_STACK_SIZE   = 1024 * 1024; // 1 MiB clone stack
constexpr int    MONITOR_INTERVAL_MS  = 1000;         // poll /proc every 1s
constexpr int    MAX_CONTAINERS       = 16;
constexpr int    IPC_MSG_KEY_BASE     = 0x4C425800;   // "LBX\0"
constexpr mode_t ROOTFS_PERMS        = 0755;
