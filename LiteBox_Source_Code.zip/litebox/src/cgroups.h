#pragma once
// ============================================================
// LiteBox — cgroups.h
// Resource enforcement using cgroups v2  (Lab 06 + OS Concept)
// Writes CPU quota and memory.max to /sys/fs/cgroup/<id>/
// ============================================================

#include "utils.h"
#include <string>
#include <iostream>

#define CGROUP_ROOT "/sys/fs/cgroup/litebox"

class CgroupController {
public:
    // -------------------------------------------------------
    // create() — create a cgroup for a container
    // Returns path to the created cgroup dir
    // -------------------------------------------------------
    static std::string create(const std::string& id) {
        std::string path = std::string(CGROUP_ROOT) + "/" + id;
        mkdir_p(path);

        // Enable controllers in the parent cgroup subtree
        // (required for cgroups v2 delegation)
        file_write(std::string(CGROUP_ROOT) + "/cgroup.subtree_control",
                   "+cpu +memory +pids");

        std::cout << "[cgroup] Created cgroup at " << path << "\n";
        return path;
    }

    // -------------------------------------------------------
    // apply_limits() — write cpu and memory limits
    //   mem_mb: max memory in MiB (0 = no limit)
    //   cpu_pct: cpu quota percentage (0 = no limit)
    // -------------------------------------------------------
    static void apply_limits(const std::string& cgroup_path,
                              long   mem_mb,
                              int    cpu_pct)
    {
        // --- Memory limit (Lab core: cgroups v2) ---
        if (mem_mb > 0) {
            long mem_bytes = mem_mb * 1024 * 1024;
            file_write(cgroup_path + "/memory.max",
                       std::to_string(mem_bytes));
            file_write(cgroup_path + "/memory.swap.max", "0"); // no swap
            std::cout << "[cgroup] Memory limit: " << mem_mb << " MiB\n";
        } else {
            file_write(cgroup_path + "/memory.max", "max");
        }

        // --- CPU limit (cgroups v2 uses cpu.max = quota period) ---
        // cpu.max format: "quota_us period_us"
        // Example: 50% of one core => "50000 100000"
        if (cpu_pct > 0 && cpu_pct <= 100) {
            int quota  = cpu_pct * 1000; // microseconds per 100ms period
            int period = 100000;
            std::string cpu_max = std::to_string(quota) + " " + std::to_string(period);
            file_write(cgroup_path + "/cpu.max", cpu_max);
            std::cout << "[cgroup] CPU limit: " << cpu_pct << "%\n";
        } else {
            file_write(cgroup_path + "/cpu.max", "max 100000");
        }

        // --- PID limit: max 64 processes per container ---
        file_write(cgroup_path + "/pids.max", "64");
    }

    // -------------------------------------------------------
    // assign() — add a PID to this cgroup
    // -------------------------------------------------------
    static void assign(const std::string& cgroup_path, pid_t pid) {
        file_write(cgroup_path + "/cgroup.procs", std::to_string(pid));
        std::cout << "[cgroup] Assigned PID " << pid
                  << " to " << cgroup_path << "\n";
    }

    // -------------------------------------------------------
    // destroy() — remove cgroup after container stops
    // -------------------------------------------------------
    static void destroy(const std::string& cgroup_path) {
        // First kill all remaining processes
        run_cmd("[ -f " + cgroup_path + "/cgroup.procs ] && "
                "cat " + cgroup_path + "/cgroup.procs | xargs -r kill -9 2>/dev/null; true");
        // rmdir only works on an empty cgroup
        run_cmd("rmdir " + cgroup_path + " 2>/dev/null || true");
        std::cout << "[cgroup] Destroyed " << cgroup_path << "\n";
    }

    // -------------------------------------------------------
    // read_mem_usage() — return current RSS in KB
    // -------------------------------------------------------
    static long read_mem_usage(const std::string& cgroup_path) {
        std::string raw = file_read(cgroup_path + "/memory.current");
        if (raw.empty()) return 0;
        try { return std::stol(raw) / 1024; } // bytes → KB
        catch (...) { return 0; }
    }

    // -------------------------------------------------------
    // is_available() — check if cgroups v2 is mounted
    // -------------------------------------------------------
    static bool is_available() {
        return exists("/sys/fs/cgroup/cgroup.controllers");
    }
};
