#pragma once
// ============================================================
// LiteBox — snapshot.h
// Copy-on-write filesystem snapshots (save / restore)
// Uses hard links + rsync for efficient snapshots
// Lab 10: C++ file I/O for metadata
// ============================================================

#include "utils.h"
#include <string>
#include <iostream>
#include <fstream>

#define SNAPSHOT_DIR "/var/lib/litebox/snapshots"

class SnapshotEngine {
public:
    // -------------------------------------------------------
    // save() — snapshot a container's rootfs
    //   Returns snapshot name (id-timestamp) or "" on failure
    // -------------------------------------------------------
    static std::string save(const std::string& container_id,
                             const std::string& rootfs_path)
    {
        if (!exists(rootfs_path)) {
            std::cerr << "[snapshot] rootfs not found: " << rootfs_path << "\n";
            return "";
        }

        std::string ts   = now_iso();
        // Replace colons in timestamp for a valid dir name
        for (char& c : ts) if (c == ':') c = '-';

        std::string snap_name = container_id + "-" + ts;
        std::string snap_path = std::string(SNAPSHOT_DIR) + "/" + snap_name;

        mkdir_p(SNAPSHOT_DIR);
        mkdir_p(snap_path + "/rootfs");

        // Use rsync with hard-links for efficient copy (CoW semantics)
        std::string cmd = "rsync -a --link-dest=" + rootfs_path + "/ "
                        + rootfs_path + "/ " + snap_path + "/rootfs/ 2>/dev/null";
        if (run_cmd(cmd) != 0) {
            // Fallback to plain cp
            run_cmd("cp -a " + rootfs_path + "/. " + snap_path + "/rootfs/");
        }

        // Write metadata (Lab 10: ofstream)
        write_metadata(snap_path, container_id, rootfs_path, ts);

        std::cout << "[snapshot] Saved: " << snap_name << "\n";
        file_append("/var/lib/litebox/events.log",
                    "SNAPSHOT container=" + container_id + " snap=" + snap_name);
        return snap_name;
    }

    // -------------------------------------------------------
    // restore() — overwrite rootfs from a snapshot
    // -------------------------------------------------------
    static bool restore(const std::string& snap_name,
                         const std::string& target_rootfs)
    {
        std::string snap_path = std::string(SNAPSHOT_DIR) + "/" + snap_name;
        std::string snap_rootfs = snap_path + "/rootfs";

        if (!exists(snap_rootfs)) {
            std::cerr << "[snapshot] Snapshot not found: " << snap_name << "\n";
            return false;
        }

        mkdir_p(target_rootfs);
        // Sync snapshot back to rootfs
        std::string cmd = "rsync -a --delete " + snap_rootfs + "/ "
                        + target_rootfs + "/ 2>/dev/null";
        int ret = run_cmd(cmd);
        if (ret == 0) {
            std::cout << "[snapshot] Restored " << snap_name
                      << " → " << target_rootfs << "\n";
            file_append("/var/lib/litebox/events.log",
                        "RESTORE snap=" + snap_name + " target=" + target_rootfs);
        } else {
            std::cerr << "[snapshot] Restore failed (rsync error)\n";
        }
        return ret == 0;
    }

    // -------------------------------------------------------
    // list() — print available snapshots
    // -------------------------------------------------------
    static void list() {
        std::string cmd = "ls " + std::string(SNAPSHOT_DIR) + " 2>/dev/null || "
                          "echo '(no snapshots)'";
        std::cout << "[snapshot] Available snapshots:\n";
        system(cmd.c_str());
    }

private:
    // -------------------------------------------------------
    // write_metadata() — store snapshot info as a text file
    //                    (Lab 10: C++ file handling)
    // -------------------------------------------------------
    static void write_metadata(const std::string& snap_path,
                                const std::string& container_id,
                                const std::string& rootfs_path,
                                const std::string& timestamp)
    {
        std::ofstream meta(snap_path + "/metadata.txt");
        if (!meta.is_open()) return;
        meta << "container_id=" << container_id << "\n"
             << "rootfs_path="  << rootfs_path  << "\n"
             << "timestamp="    << timestamp     << "\n"
             << "created_by=LiteBox v1.0\n";
    }
};
