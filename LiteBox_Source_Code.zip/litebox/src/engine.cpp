// ============================================================
// LiteBox — engine.cpp
// Core container engine: clone(), namespaces, pivot_root()
// Lab 05: Process management | Lab 06: C++ & system calls
// Lab 07: IPC | Lab 08: Threads | Lab 09: Sync
// ============================================================

#define _GNU_SOURCE
#include <sched.h>      // clone(), CLONE_NEW*
#include <unistd.h>     // fork, execve, chdir, chroot
#include <sys/wait.h>   // waitpid
#include <sys/mount.h>  // mount
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <cstring>
#include <cerrno>
#include <csignal>
#include <iostream>
#include <sstream>
#include <vector>

#include "container.h"
#include "registry.h"
#include "cgroups.h"
#include "network.h"
#include "monitor.h"
#include "ipc.h"
#include "snapshot.h"
#include "utils.h"

// ============================================================
// Global singletons
// ============================================================
static Registry*      g_registry = nullptr;
static MonitorThread* g_monitor  = nullptr;
static IpcBus*        g_ipc      = nullptr;
static int            g_slot     = 0;  // IPC slot counter

// ============================================================
// ContainerArgs — passed into the cloned child via void*
// ============================================================
struct ContainerArgs {
    ContainerConfig config;
    std::string     rootfs;
};

// ============================================================
// container_child() — runs INSIDE the new namespaces
//   Called by clone() with its own PID/Mount/UTS/Net namespace
// ============================================================
static int container_child(void* arg) {
    auto* cargs  = static_cast<ContainerArgs*>(arg);
    auto& config = cargs->config;
    auto& rootfs = cargs->rootfs;

    // --- Set hostname (UTS namespace, Lab 06: system calls) ---
    sethostname(config.hostname.c_str(), config.hostname.size());

    // --- Filesystem isolation: pivot_root (chroot jail) ---
    // 1. Make rootfs a mount point (bind-mount onto itself)
    if (mount(rootfs.c_str(), rootfs.c_str(), "bind",
              MS_BIND | MS_REC, nullptr) != 0) {
        // Fallback: try plain chroot
        if (chroot(rootfs.c_str()) != 0 || chdir("/") != 0) {
            std::cerr << "[child] chroot failed: " << strerror(errno) << "\n";
            // Continue anyway for demo purposes
        }
    } else {
        // 2. Create .put_old inside rootfs for old root
        std::string put_old = rootfs + "/.put_old";
        mkdir(put_old.c_str(), 0700);

        // 3. pivot_root — swap rootfs and old root
        if (syscall(SYS_pivot_root, rootfs.c_str(), put_old.c_str()) == 0) {
            chdir("/");
            // 4. Unmount old root (detach host filesystem)
            umount2("/.put_old", MNT_DETACH);
            rmdir("/.put_old");
        } else {
            // Fallback to chroot if pivot_root unavailable
            chroot(rootfs.c_str());
            chdir("/");
        }
    }

    // --- Mount proc (so ps/top work inside container) ---
    mkdir("/proc", 0755);
    mount("proc", "/proc", "proc",
          MS_NOSUID | MS_NOEXEC | MS_NODEV, nullptr);

    // --- Mount tmpfs for /tmp ---
    mkdir("/tmp", 01777);
    mount("tmpfs", "/tmp", "tmpfs", 0, "size=64m");

    // --- Drop to a shell or run the specified command ---
    std::string cmd = config.command.empty() ? "/bin/sh" : config.command;

    // Log start (Lab 10: file I/O, Lab 04: timestamps)
    file_append("/tmp/litebox.log",
                "EXEC container=" + config.id + " cmd=" + cmd);

    // exec the command (Lab 06: execve)
    char* argv[] = { (char*)cmd.c_str(), nullptr };
    char* envp[] = {
        (char*)"PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
        (char*)"TERM=xterm-256color",
        nullptr
    };
    execve(cmd.c_str(), argv, envp);

    // execve only returns on error
    std::cerr << "[child] execve(" << cmd << ") failed: "
              << strerror(errno) << "\n";
    return 1;
}

// ============================================================
// run_container() — spawn a container using clone()
// ============================================================
pid_t run_container(const ContainerConfig& config) {
    // Build rootfs path
    std::string rootfs = std::string(LITEBOX_RUN_DIR) + config.id + "/rootfs";
    mkdir_p(rootfs);

    // If image is a directory, bootstrap rootfs from it
    if (exists(config.image) && config.image != rootfs) {
        run_cmd("rsync -a " + config.image + "/. " + rootfs + "/ 2>/dev/null || "
                "cp -a " + config.image + "/. " + rootfs + "/");
    } else if (!exists(rootfs + "/bin")) {
        // Bare minimum: create essential directories
        for (auto& d : {"bin","etc","proc","tmp","dev","sys","usr"})
            mkdir_p(rootfs + "/" + std::string(d));
        // Copy busybox or /bin/sh from host as minimal shell
        run_cmd("cp /bin/sh "     + rootfs + "/bin/sh 2>/dev/null || true");
        run_cmd("cp /bin/busybox "+ rootfs + "/bin/busybox 2>/dev/null || true");
        run_cmd("[ -f " + rootfs + "/bin/busybox ] && "
                "chroot " + rootfs + " /bin/busybox --install -s /bin 2>/dev/null || true");
    }

    // Allocate stack for the cloned child (Lab 06)
    std::vector<char> stack(LITEBOX_STACK_SIZE);
    char* stack_top = stack.data() + LITEBOX_STACK_SIZE;

    // Prepare args for child
    ContainerArgs* cargs = new ContainerArgs{config, rootfs};

    // clone() flags: new PID, Mount, UTS, IPC, Network namespaces
    int flags = CLONE_NEWPID | CLONE_NEWNS | CLONE_NEWUTS
              | CLONE_NEWIPC | CLONE_NEWNET | SIGCHLD;

    pid_t child_pid = clone(container_child, stack_top, flags, cargs);

    if (child_pid < 0) {
        perror("[engine] clone() failed");
        delete cargs;
        return -1;
    }

    std::cout << Color::GREEN << "[engine] Container " << config.id
              << " spawned with PID " << child_pid << Color::RESET << "\n";

    // --- Setup cgroup for resource limits ---
    std::string cgroup_path = CgroupController::create(config.id);
    if (!cgroup_path.empty()) {
        CgroupController::apply_limits(cgroup_path,
                                        config.mem_limit_mb,
                                        config.cpu_quota);
        CgroupController::assign(cgroup_path, child_pid);
    }

    // --- Network setup (veth pair) ---
    std::string veth_host, veth_cont, ip_addr;
    if (config.network) {
        ip_addr = NetworkManager::setup_veth(config.id, child_pid,
                                              veth_host, veth_cont);
    }

    // --- Register container ---
    ContainerInfo info;
    info.config      = config;
    info.pid         = child_pid;
    info.state       = ContainerState::RUNNING;
    info.veth_host   = veth_host;
    info.veth_cont   = veth_cont;
    info.ip_addr     = ip_addr;
    info.start_time  = now_iso();
    info.rootfs      = rootfs;
    info.cgroup_path = cgroup_path;

    if (g_registry) g_registry->add(info);

    // Update IPC shared memory (Lab 07)
    if (g_ipc) g_ipc->update_status(g_slot++, config.id,
                                      child_pid, ContainerState::RUNNING);

    // Log event (Lab 04: timestamps, Lab 10: file I/O)
    file_append("/var/lib/litebox/events.log",
                "RUN id=" + config.id + " pid=" + std::to_string(child_pid)
                + " image=" + config.image + " ip=" + ip_addr);

    return child_pid;
}

// ============================================================
// stop_container() — send SIGTERM then SIGKILL to container
// ============================================================
bool stop_container(const std::string& id) {
    if (!g_registry) return false;

    ContainerInfo info;
    if (!g_registry->get(id, info)) {
        std::cerr << "[engine] Container " << id << " not found\n";
        return false;
    }

    // Send SIGTERM first (Lab 05: kill)
    kill(info.pid, SIGTERM);
    usleep(500000); // 500ms grace period

    // Then SIGKILL if still alive
    if (kill(info.pid, 0) == 0) kill(info.pid, SIGKILL);

    // waitpid to reap (Lab 05: wait)
    int status;
    waitpid(info.pid, &status, WNOHANG);

    // Teardown networking
    if (!info.veth_host.empty())
        NetworkManager::teardown_veth(info.veth_host);

    // Destroy cgroup
    if (!info.cgroup_path.empty())
        CgroupController::destroy(info.cgroup_path);

    g_registry->remove(id);

    file_append("/var/lib/litebox/events.log",
                "STOP id=" + id + " pid=" + std::to_string(info.pid));

    std::cout << Color::YELLOW << "[engine] Container " << id
              << " stopped\n" << Color::RESET;
    return true;
}

// ============================================================
// list_containers() — print all running containers (Lab 05)
// ============================================================
void list_containers() {
    if (!g_registry || g_registry->count() == 0) {
        std::cout << "[litebox] No containers running.\n";
        return;
    }
    printf("%-12s %-8s %-10s %-20s %-16s\n",
           "ID", "PID", "STATUS", "IMAGE", "IP");
    std::cout << std::string(68, '-') << "\n";
    for (auto& [id, info] : g_registry->all()) {
        std::string state_str =
            info.state == ContainerState::RUNNING  ? "RUNNING"  :
            info.state == ContainerState::STOPPED   ? "STOPPED"  : "PAUSED";
        printf("%-12s %-8d %-10s %-20s %-16s\n",
               id.substr(0,8).c_str(),
               info.pid,
               state_str.c_str(),
               info.config.image.substr(0, 19).c_str(),
               info.ip_addr.c_str());
    }
}

// ============================================================
// main() — entry point, parse sub-commands
// ============================================================
int main(int argc, char* argv[]) {
    // Print banner
    std::cout << Color::CYAN << Color::BOLD
              << "  _     _ _       ____            \n"
              << " | |   (_) |_ ___| __ )  _____  __\n"
              << " | |   | | __/ _ \\  _ \\ / _ \\ \\/ /\n"
              << " | |___| | ||  __/ |_) | (_) >  < \n"
              << " |_____|_|\\__\\___|____/ \\___/_/\\_\\\n"
              << Color::RESET
              << Color::BOLD << " Lightweight Linux Container Runtime v1.0\n"
              << " Abdul Moiz Israr | SP24-BCS-002 | BCS-5A\n"
              << Color::RESET << "\n";

    if (argc < 2) {
        std::cout << "Usage: litebox <command> [options]\n"
                  << "Commands:\n"
                  << "  run    <image> [cmd] [--mem MB] [--cpu %] [--name NAME]\n"
                  << "  stop   <id>\n"
                  << "  list\n"
                  << "  stats\n"
                  << "  snapshot <id>\n"
                  << "  restore  <snapshot-name> <id>\n"
                  << "  ipc-send <from-id> <to-id> <message>\n";
        return 1;
    }

    // Initialise singletons
    mkdir_p("/var/lib/litebox/containers");
    g_registry = new Registry();
    g_ipc      = new IpcBus();
    g_ipc->init();
    g_monitor  = new MonitorThread(g_registry);

    std::string cmd = argv[1];

    // -------------------------------------------------------
    // litebox run <image> [options]
    // -------------------------------------------------------
    if (cmd == "run") {
        if (argc < 3) { std::cerr << "Usage: litebox run <image>\n"; return 1; }

        ContainerConfig cfg;
        cfg.id           = generate_id();
        cfg.image        = argv[2];
        cfg.command      = (argc >= 4) ? argv[3] : "/bin/sh";
        cfg.hostname     = "litebox-" + cfg.id.substr(0, 6);
        cfg.mem_limit_mb = 128;  // default 128 MiB
        cfg.cpu_quota    = 50;   // default 50%
        cfg.network      = true;

        // Parse optional flags
        for (int i = 4; i < argc - 1; i++) {
            std::string flag = argv[i];
            if (flag == "--mem"  && i+1 < argc) cfg.mem_limit_mb = std::stol(argv[++i]);
            if (flag == "--cpu"  && i+1 < argc) cfg.cpu_quota    = std::stoi(argv[++i]);
            if (flag == "--name" && i+1 < argc) cfg.hostname     = argv[++i];
        }

        pid_t pid = run_container(cfg);
        if (pid < 0) { std::cerr << "[engine] Failed to start container.\n"; return 1; }

        std::cout << Color::GREEN << "Container ID: " << cfg.id
                  << "\nPID: " << pid << Color::RESET << "\n";

        // Wait for child (Lab 05: waitpid)
        int status;
        waitpid(pid, &status, 0);
        stop_container(cfg.id);

    // -------------------------------------------------------
    // litebox stop <id>
    // -------------------------------------------------------
    } else if (cmd == "stop") {
        if (argc < 3) { std::cerr << "Usage: litebox stop <id>\n"; return 1; }
        stop_container(argv[2]);

    // -------------------------------------------------------
    // litebox list
    // -------------------------------------------------------
    } else if (cmd == "list") {
        list_containers();

    // -------------------------------------------------------
    // litebox stats  — starts the dashboard thread (Lab 08)
    // -------------------------------------------------------
    } else if (cmd == "stats") {
        std::cout << "[litebox] Starting live dashboard (Ctrl+C to quit)...\n";
        g_monitor->start();
        // Run until SIGINT
        signal(SIGINT, [](int){ });
        pause();
        g_monitor->stop();

    // -------------------------------------------------------
    // litebox snapshot <id>
    // -------------------------------------------------------
    } else if (cmd == "snapshot") {
        if (argc < 3) { std::cerr << "Usage: litebox snapshot <id>\n"; return 1; }
        ContainerInfo info;
        if (!g_registry->get(argv[2], info)) {
            std::cerr << "[litebox] Container not found: " << argv[2] << "\n";
            return 1;
        }
        std::string snap = SnapshotEngine::save(info.config.id, info.rootfs);
        if (!snap.empty())
            std::cout << "Snapshot saved: " << snap << "\n";

    // -------------------------------------------------------
    // litebox restore <snapshot-name> <target-id>
    // -------------------------------------------------------
    } else if (cmd == "restore") {
        if (argc < 4) {
            std::cerr << "Usage: litebox restore <snapshot> <container-id>\n";
            return 1;
        }
        ContainerInfo info;
        if (!g_registry->get(argv[3], info)) {
            std::cerr << "[litebox] Target container not found: " << argv[3] << "\n";
            return 1;
        }
        SnapshotEngine::restore(argv[2], info.rootfs);

    // -------------------------------------------------------
    // litebox ipc-send <from> <to> <message>
    // -------------------------------------------------------
    } else if (cmd == "ipc-send") {
        if (argc < 5) {
            std::cerr << "Usage: litebox ipc-send <from-id> <to-id> <msg>\n";
            return 1;
        }
        // mtype = numeric hash of dest id
        long mtype = std::abs((long)std::stoul(std::string(argv[3]).substr(0, 8), nullptr, 16));
        g_ipc->send_msg(argv[2], mtype, argv[4]);

    } else {
        std::cerr << "[litebox] Unknown command: " << cmd << "\n";
        return 1;
    }

    // Cleanup
    delete g_monitor;
    delete g_ipc;
    delete g_registry;
    return 0;
}
