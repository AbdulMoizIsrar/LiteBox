#pragma once
// ============================================================
// LiteBox — utils.h  |  Utility helpers
// ============================================================

#include <string>
#include <sstream>
#include <iomanip>
#include <ctime>
#include <random>
#include <fstream>
#include <iostream>
#include <sys/stat.h>

// -----------------------------------------------------------
// generate_id() — random 8-char hex container ID
// -----------------------------------------------------------
inline std::string generate_id() {
    std::mt19937 rng(std::random_device{}());
    std::uniform_int_distribution<uint32_t> dist(0, 0xFFFFFFFF);
    std::ostringstream oss;
    oss << std::hex << std::setw(8) << std::setfill('0') << dist(rng);
    return oss.str();
}

// -----------------------------------------------------------
// now_iso() — current timestamp as ISO-8601 string
// -----------------------------------------------------------
inline std::string now_iso() {
    std::time_t t = std::time(nullptr);
    char buf[32];
    std::strftime(buf, sizeof(buf), "%Y-%m-%dT%H:%M:%S", std::localtime(&t));
    return std::string(buf);
}

// -----------------------------------------------------------
// file_write() — write string to file (Lab 10: fstream)
// -----------------------------------------------------------
inline bool file_write(const std::string& path, const std::string& content) {
    std::ofstream f(path, std::ios::trunc);
    if (!f.is_open()) return false;
    f << content;
    return f.good();
}

// -----------------------------------------------------------
// file_read() — read entire file into string
// -----------------------------------------------------------
inline std::string file_read(const std::string& path) {
    std::ifstream f(path);
    if (!f.is_open()) return "";
    std::ostringstream ss;
    ss << f.rdbuf();
    return ss.str();
}

// -----------------------------------------------------------
// file_append() — append a line to a log file
// -----------------------------------------------------------
inline void file_append(const std::string& path, const std::string& line) {
    std::ofstream f(path, std::ios::app);
    if (f.is_open()) f << now_iso() << "  " << line << "\n";
}

// -----------------------------------------------------------
// mkdir_p() — recursive mkdir (wraps system call)
// -----------------------------------------------------------
inline int mkdir_p(const std::string& path) {
    return system(("mkdir -p " + path).c_str());
}

// -----------------------------------------------------------
// exists() — check if a path exists
// -----------------------------------------------------------
inline bool exists(const std::string& path) {
    struct stat st{};
    return stat(path.c_str(), &st) == 0;
}

// -----------------------------------------------------------
// run_cmd() — run a shell command, return exit code
// -----------------------------------------------------------
inline int run_cmd(const std::string& cmd) {
    return system(cmd.c_str());
}

// -----------------------------------------------------------
// ANSI colour helpers for the terminal dashboard
// -----------------------------------------------------------
namespace Color {
    inline const char* RESET  = "\033[0m";
    inline const char* BOLD   = "\033[1m";
    inline const char* RED    = "\033[31m";
    inline const char* GREEN  = "\033[32m";
    inline const char* YELLOW = "\033[33m";
    inline const char* CYAN   = "\033[36m";
    inline const char* WHITE  = "\033[37m";
    inline const char* BLUE   = "\033[34m";
}
