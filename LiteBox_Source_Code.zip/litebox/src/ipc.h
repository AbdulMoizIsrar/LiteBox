#pragma once
// ============================================================
// LiteBox — ipc.h
// Inter-Container Communication (Lab 07)
// POSIX Shared Memory (shmget/shmat) + Message Queues (msgsnd/msgrcv)
// ============================================================

#include "container.h"
#include "utils.h"
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/msg.h>
#include <cstring>
#include <iostream>

// -----------------------------------------------------------
// SharedMemoryBus — a small shared segment all containers
//                   can read/write (container status board)
// -----------------------------------------------------------
struct SharedStatusBoard {
    char     ids[MAX_CONTAINERS][9];   // container IDs
    pid_t    pids[MAX_CONTAINERS];
    int      states[MAX_CONTAINERS];   // ContainerState as int
    int      count;
    char     last_event[128];
};

class IpcBus {
public:
    IpcBus() : shm_id_(-1), msgq_id_(-1), shm_ptr_(nullptr) {}

    // -------------------------------------------------------
    // init() — create shared memory segment + message queue
    // -------------------------------------------------------
    bool init() {
        key_t shm_key  = IPC_MSG_KEY_BASE;
        key_t msgq_key = IPC_MSG_KEY_BASE + 1;

        // Shared memory (Lab 07: shmget/shmat)
        shm_id_ = shmget(shm_key, sizeof(SharedStatusBoard),
                         IPC_CREAT | 0666);
        if (shm_id_ < 0) {
            perror("[ipc] shmget failed");
            return false;
        }
        shm_ptr_ = (SharedStatusBoard*)shmat(shm_id_, nullptr, 0);
        if ((void*)shm_ptr_ == (void*)-1) {
            perror("[ipc] shmat failed");
            shm_ptr_ = nullptr;
            return false;
        }
        memset(shm_ptr_, 0, sizeof(SharedStatusBoard));

        // Message queue (Lab 07: msgget)
        msgq_id_ = msgget(msgq_key, IPC_CREAT | 0666);
        if (msgq_id_ < 0) {
            perror("[ipc] msgget failed");
            return false;
        }

        std::cout << "[ipc] Shared memory (shmid=" << shm_id_
                  << ") and message queue (msqid=" << msgq_id_
                  << ") initialised\n";
        return true;
    }

    // -------------------------------------------------------
    // update_status() — write container state into shared mem
    // -------------------------------------------------------
    void update_status(int slot, const std::string& id,
                       pid_t pid, ContainerState state)
    {
        if (!shm_ptr_ || slot >= MAX_CONTAINERS) return;
        strncpy(shm_ptr_->ids[slot], id.c_str(), 8);
        shm_ptr_->pids[slot]   = pid;
        shm_ptr_->states[slot] = (int)state;
        shm_ptr_->count        = slot + 1;
    }

    // -------------------------------------------------------
    // send_msg() — send an IPC message to a container
    //              (Lab 07: msgsnd)
    // -------------------------------------------------------
    bool send_msg(const std::string& sender,
                  long               dest_mtype,
                  const std::string& payload)
    {
        if (msgq_id_ < 0) return false;
        IpcMessage msg{};
        msg.mtype = dest_mtype;
        strncpy(msg.sender,  sender.c_str(),  15);
        strncpy(msg.payload, payload.c_str(), 223);

        if (msgsnd(msgq_id_, &msg, sizeof(msg) - sizeof(long), IPC_NOWAIT) < 0) {
            perror("[ipc] msgsnd failed");
            return false;
        }
        std::cout << "[ipc] Message sent from " << sender
                  << " → mtype " << dest_mtype << "\n";
        return true;
    }

    // -------------------------------------------------------
    // recv_msg() — receive a message (Lab 07: msgrcv)
    // -------------------------------------------------------
    bool recv_msg(long mtype, IpcMessage& out) {
        if (msgq_id_ < 0) return false;
        ssize_t ret = msgrcv(msgq_id_, &out,
                             sizeof(out) - sizeof(long),
                             mtype, IPC_NOWAIT);
        return ret > 0;
    }

    // -------------------------------------------------------
    // destroy() — detach shared memory, destroy resources
    // -------------------------------------------------------
    void destroy() {
        if (shm_ptr_) {
            shmdt(shm_ptr_);
            shm_ptr_ = nullptr;
        }
        if (shm_id_ >= 0) { shmctl(shm_id_, IPC_RMID, nullptr); shm_id_ = -1; }
        if (msgq_id_ >= 0) { msgctl(msgq_id_, IPC_RMID, nullptr); msgq_id_ = -1; }
    }

    ~IpcBus() { destroy(); }

private:
    int                 shm_id_;
    int                 msgq_id_;
    SharedStatusBoard*  shm_ptr_;
};
